#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>
#include <sensor_msgs/image_encodings.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/core/core.hpp>
#include <geometry_msgs/Twist.h>
#include <std_msgs/Empty.h>
#include <std_srvs/Empty.h>
#include <iostream>
#include <chrono>
#include <vector>

using namespace cv;
using namespace std;
using namespace ros; 

/* Drone Functions */
Publisher topictakeoff;
Publisher topiclanding;
ServiceClient serviceflattrim;
Publisher cmd_vel;
Publisher topicinfo;
float logitud, latitud, altitud;

geometry_msgs::Twist changeTwist(float x, float y, float z, float turn)
{
    geometry_msgs::Twist msg_vel;
    msg_vel.angular.x = 0;
    msg_vel.angular.y = 0;
    msg_vel.angular.z = turn;
    msg_vel.linear.x = x;
    msg_vel.linear.y = y;
    msg_vel.linear.z = z;
    return (msg_vel);
}

void ajuste(void)
{
    std_srvs::Empty srvflattrim;
    serviceflattrim.call(srvflattrim);
}

void takeoff(void)
{
    std_msgs::Empty empty;
    geometry_msgs::Twist msg_vel;
    topictakeoff.publish(empty);
    printf("Starting...\n");
    usleep(250000);
    printf("hoverring...\n");
    msg_vel = changeTwist(0, 0, 0, 0);
    cmd_vel.publish(msg_vel);
}

void land(void)
{
    std_msgs::Empty empty;
    topiclanding.publish(empty);
}

void forwardx(void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(1, 0, 0, 0);
    cmd_vel.publish(msg_vel);
}

void forwardy(void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0, 1, 0, 0);
    cmd_vel.publish(msg_vel);
}

void backx(void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(-1, 0, 0, 0);
    cmd_vel.publish(msg_vel);
}

void backy(void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0, -1, 0, 0);
    cmd_vel.publish(msg_vel);
}

void up(void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0, 0, 1, 0);
    cmd_vel.publish(msg_vel);
}

void down(void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0, 0, -1, 0);
    cmd_vel.publish(msg_vel);
}

void stop(void)
{
    geometry_msgs::Twist msg_vel;
    msg_vel = changeTwist(0, 0, 0, 0);
    cmd_vel.publish(msg_vel);
    printf("Stopping...\n");
}

static const std::string OPENCV_WINDOW = "Image window";

class ImageConverter
{
  ros::NodeHandle nh_;
  image_transport::ImageTransport it_;
  image_transport::Subscriber image_sub_;
  image_transport::Subscriber tmage_sub_depth;
  image_transport::Subscriber image_sub_threshold;
  image_transport::Publisher image_pub_;
  image_transport::Publisher image_pub_depth;
  image_transport::Publisher image_pub_threshold;

public:
  ImageConverter()
    : it_(nh_)
  {
    // Subscrive to input video feed and publish output video feed
    image_sub_ = it_.subscribe("/camera/image_raw", 1,
      &ImageConverter::imageCb, this);
    image_pub_ = it_.advertise("/image_converter/output_video", 1);

    cv::namedWindow(OPENCV_WINDOW);
  }

  ~ImageConverter()
  {
    cv::destroyWindow(OPENCV_WINDOW);
  }

  void imageCb(const sensor_msgs::ImageConstPtr& msg)
  {
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }

    // // Draw an example circle on the video stream
    // if (cv_ptr->image.rows > 60 && cv_ptr->image.cols > 60)
    //   cv::circle(cv_ptr->image, cv::Point(50, 50), 10, CV_RGB(255,0,0));

    // // Update GUI Window
    // cv::imshow(OPENCV_WINDOW, cv_ptr->image);
    // cv::waitKey(3);

    // // Output modified video stream
    // image_pub_.publish(cv_ptr->toImageMsg());

    //-----------------------------------------------------------------------------------------
    cv::Mat HSVImage;
    cv::cvtColor(cv_ptr->image, HSVImage, CV_BGR2HSV); //HSV
    cv::Size size = HSVImage.size();
    cv::Mat mask = cvCreateMat(size.height, size.width, CV_8UC1);                  //CV_8UC1 = grayscle mask
    cv::inRange(HSVImage, cv::Scalar(0, 198, 79), cv::Scalar(0, 255, 255), mask); //detecting colors --> starting with higher contrast to lower 

    //morphological closing (fill small holes in the foreground)
    dilate(mask, mask, getStructuringElement(0, Size(21, 21)));
    erode(mask, mask, getStructuringElement(0, Size(10, 10)));

    //opening
    erode(mask, mask, getStructuringElement(0, Size(11, 11)));
    dilate(mask, mask, getStructuringElement(0, Size(5, 5)));

    GaussianBlur(mask, mask, Size(15, 15), 2, 2);
    vector<Vec3f> circles;
    HoughCircles(mask, circles, CV_HOUGH_GRADIENT, 1.5, size.height / 10, 100, 40, 0, 0); // hough transform

    
    //Processing the circle and recognising it's center
        float x, y, r;
        for (size_t i = 0; i < circles.size(); i++)
        {
            Point center(cvRound(circles[i][0]), cvRound(circles[i][1]));
            int radius = cvRound(circles[i][2]);
            // circle center
            circle(mask, center, 3, Scalar(0, 255, 8), -1, 8, 0);
            // circle outline
            circle(mask, center, radius, Scalar(0, 0, 255), 3, 8, 0);
            // circle center
            circle(cv_ptr->image, center, 3, Scalar(0, 255, 0), -1, 8, 0);
            // circle outline
            circle(cv_ptr->image, center, radius, Scalar(0, 0, 255), 3, 8, 0);
            x = circles[i][0];
            y = circles[i][1];
            r = circles[i][2];
        }
        if (circles.size() > 0)
        {
          printf("Coordinates x: %f \n Coordinates y: %f \n radial %f \n", x, y, r /*, circles.size()*/);
        }

        bool temp1, temp2; //help variables
        if (circles.size() == 0)
        {
            stop();
        }

        if (r < 20 && circles.size() > 0)
        {
            forwardx();
            temp1 = true;
        }

        if (r > 40)
        {
            backx();
            temp1 = true;
        }

        if (r < 40 && r > 20)
        {
            if (temp1 == true)
            {
                stop();
                temp1 = false;
            }

            if (y < 200 && circles.size() > 0) //go up
            {
                up();
                temp2 = true;
            }

            if (y > 300 && circles.size() > 0) // go down
            {
                down();
                temp2 = true;
            }

            if (y < 300 && y > 200)
            {
                if (temp2 == true)
                {
                    stop();
                    temp2 = false;
                }

                if (x > 350 && circles.size() > 0)
                {
                    backy();
                }
                if (x < 250 && circles.size() > 0)
                {
                    forwardy();
                }
                if (x < 350 && x > 250)
                {
                    stop();
                }
            }
        }

        cv::imshow(OPENCV_WINDOW, cv_ptr->image); //show detected object
  }
};

int main(int argc, char** argv)
{
  // -------- DRONE PART
  ros::init(argc, argv, "drone");
  ros::NodeHandle n;
  topictakeoff = n.advertise<std_msgs::Empty>("/ardrone/takeoff", 1, true);
  topiclanding = n.advertise<std_msgs::Empty>("/ardrone/land", 1, true);
  cmd_vel = n.advertise<geometry_msgs::Twist>("/cmd_vel", 1, true);
  serviceflattrim = n.serviceClient<std_srvs::Empty>("/ardrone/flattrim");
  ajuste();
  printf("Calibration \n");
  takeoff();

// ------ IMAGE PART
  ros::init(argc, argv, "image_converter");
  ImageConverter ic;
  ros::spin();
  return 0;
}
